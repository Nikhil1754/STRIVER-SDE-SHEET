#include <bits/stdc++.h>
using namespace std;
class Node{
  public:
  int data;
  Node *left;
  Node *right;
  Node(int x){
    data=x;
    left=NULL;
    right=NULL;
  }
};
void PreOrderWithoutRecuur(Node* root){
  stack<Node*>s;
  s.push(root);
  while(!s.empty()){
    Node *n=s.top();
    s.pop();
    if(n->right!=NULL) s.push(n->right);
    if(n->left!=NULL) s.push(n->left);
    cout<<n->data<<" ";
  }
}
void InorderWithoutReccur(Node* root){
  stack<Node*>s;
  Node* node=root;
  while(true){
    if(node!=NULL){
    s.push(node);
    node=node->left;
   }
  else{
    if(s.empty()) break;
    node=s.top();
    s.pop();
    cout<<node->data<<" ";
    node=node->right;
  }
  }
  
}
int main() 
{
  Node * root=new Node(5);
  root->left=new Node(4);
  root->right=new Node(6);
  root->left->left=new Node(3);
  root->left->right=new Node(2);
  root->right->left=new Node(7);
  root->right->right=new Node(8);
  cout<<"Inoder Traversal Is=>";
  PreOrderWithoutRecuur(root);
  cout<<endl;
  InorderWithoutReccur(root);
    return 0;
}